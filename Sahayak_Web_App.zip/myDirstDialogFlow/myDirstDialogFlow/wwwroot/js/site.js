﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
// Get the input field

window.setInterval(function () {
    debugger;
    $.getJSON('https://console.dialogflow.com/api-client/demo/embedded/8ac59696-5ed4-487c-a5ed-8b3e8cbd1992', function (data) {
        var x = data;
    });
}, 5000);
debugger;
document.getElementById("query").nodeValue = "hello";
var input = document.getElementById("query");

// Execute a function when the user releases a key on the keyboard
input.addEventListener("keyup", function (event) {
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
        var json = $.parseJSON($("#iframe").contents().text());
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        //document.getElementById("myBtn").click();
    }
});
var json = $.parseJSON($("#iframe").contents().text());
var lang = 'en';
function langHoverOut() {
    langSelect(lang);
}
function langHover(type) {
        
    if (type == "en") {
        document.getElementById('selectEnglish').style.backgroundColor = 'darkorange';
        document.getElementById('selectMarathi').style.backgroundColor = 'gray';
        document.getElementById('eng').className = 'langSelected';
        document.getElementById('mar').className = 'langSelectedFalse';
        document.getElementById('englishText').style.display = 'block';
        document.getElementById('marathiText').style.display = 'none';
    }
    if (type == "mr") {
        document.getElementById('selectEnglish').style.backgroundColor = 'gray';
        document.getElementById('selectMarathi').style.backgroundColor = 'darkorange';
        document.getElementById('mar').className = 'langSelected';
        document.getElementById('eng').className = 'langSelectedFalse';
        document.getElementById('englishText').style.display = 'none';
        document.getElementById('marathiText').style.display = 'block';

    }
    document.get
}
function langSelect(type) {
        
    if (type == "en") {
        document.getElementById('selectEnglish').style.backgroundColor = 'darkorange';
        document.getElementById('selectMarathi').style.backgroundColor = 'gray';
        document.getElementById('eng').className = 'langSelected';
        document.getElementById('mar').className = 'langSelectedFalse';
        document.getElementById('englishText').style.display = 'block';
        document.getElementById('marathiText').style.display = 'none';
        lang = 'en';
    }
    if (type == "mr") {
        document.getElementById('selectEnglish').style.backgroundColor = 'gray';
        document.getElementById('selectMarathi').style.backgroundColor = 'darkorange';
        document.getElementById('mar').className = 'langSelected';
        document.getElementById('eng').className = 'langSelectedFalse';
        document.getElementById('englishText').style.display = 'none';
        document.getElementById('marathiText').style.display = 'block';
        lang = 'mr';
    }
    document.get
}